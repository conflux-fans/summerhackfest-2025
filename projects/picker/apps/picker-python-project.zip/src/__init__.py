"""
picker-python-project

This is a sample project for picker python.
"""

__version__ = "0.1.0"
__author__ = "Aiqubit <aiqubit@hotmail.com>"
__license__ = "MIT"
